import os
from pathlib import Path
from dotenv import dotenv_values
root = Path(r'C:\Users\hp\Downloads\PFE_PROJET_chorouk')
for p in [root / '.env', root / 'Backend' / '.env']:
    data = dotenv_values(p)
    print('FILE', p)
    print('MONGO_URI', data.get('MONGO_URI'))
    print('MONGO_DB_NAME', data.get('MONGO_DB_NAME'))
