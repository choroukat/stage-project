﻿import os
from pymongo import MongoClient
from dotenv import load_dotenv

load_dotenv(r"C:\Users\hp\Downloads\PFE_PROJET_chorouk\Backend\.env")
client = MongoClient(os.getenv("MONGO_URI"))
db = client[os.getenv("MONGO_DB_NAME", "nova_db")]
print("users", db["users"].count_documents({}))
print("employees", db["employees"].count_documents({}))
print("certificates", db["certificates"].count_documents({}))
print("trainings", db["trainings"].count_documents({}))
print("sample_user", db["users"].find_one({"email": "hr1@nttdata.com"}, {"_id": 0, "email": 1, "role": 1, "full_name": 1}))
