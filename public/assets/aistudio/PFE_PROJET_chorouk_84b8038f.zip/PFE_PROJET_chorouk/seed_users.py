"""Create test HR and manager users in the MongoDB database.

Usage:
    python seed_users.py
"""

import os
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv
from passlib.context import CryptContext
from pymongo import MongoClient


ROOT_DIR = Path(__file__).resolve().parent
for env_file in [ROOT_DIR / ".env", ROOT_DIR / "Backend" / ".env"]:
    if env_file.exists():
        load_dotenv(env_file, override=True)

MONGO_URI = os.getenv("MONGO_URI")
MONGO_DB_NAME = os.getenv("MONGO_DB_NAME", "nova_db")

if not MONGO_URI:
    raise RuntimeError("MONGO_URI is missing. Add it to the .env file.")

client = MongoClient(MONGO_URI)
db = client[MONGO_DB_NAME]
users_col = db["users"]

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

users_to_create = [
    {
        "full_name": "HR One",
        "email": "hr1@nttdata.com",
        "password": "hr11234",
        "role": "hr",
        "department": "Ressources Humaines",
        "phone": "+212 6 61 00 00 01",
        "joined_at": "2022-03-15",
        "location": "Tanger, Maroc",
    },
    {
        "full_name": "HR Two",
        "email": "hr2@nttdata.com",
        "password": "hr21234",
        "role": "hr",
        "department": "Ressources Humaines",
        "phone": "+212 6 61 00 00 02",
        "joined_at": "2021-09-01",
        "location": "Casablanca, Maroc",
    },
    {
        "full_name": "HR Three",
        "email": "hr3@nttdata.com",
        "password": "hr31234",
        "role": "hr",
        "department": "Talent Management",
        "phone": "+212 6 61 00 00 03",
        "joined_at": "2023-01-10",
        "location": "Rabat, Maroc",
    },
    {
        "full_name": "Manager One",
        "email": "manager1@nttdata.com",
        "password": "manager11234",
        "role": "management",
        "department": "IT & Digital",
        "phone": "+212 6 62 00 00 01",
        "joined_at": "2019-04-01",
        "location": "Tanger, Maroc",
    },
    {
        "full_name": "Manager Two",
        "email": "manager2@nttdata.com",
        "password": "manager21234",
        "role": "management",
        "department": "Finance & Controlling",
        "phone": "+212 6 62 00 00 02",
        "joined_at": "2018-07-15",
        "location": "Casablanca, Maroc",
    },
    {
        "full_name": "Manager Three",
        "email": "manager3@nttdata.com",
        "password": "manager31234",
        "role": "management",
        "department": "Operations",
        "phone": "+212 6 62 00 00 03",
        "joined_at": "2020-02-28",
        "location": "Rabat, Maroc",
    },
]

for user in users_to_create:
    existing = users_col.find_one({"email": user["email"]})
    if existing:
        print(f"⚠️  {user['email']} already exists, skipped.")
        continue

    doc = {
        "full_name": user["full_name"],
        "email": user["email"],
        "hashed_password": pwd_context.hash(user["password"]),
        "role": user["role"],
        "department": user.get("department"),
        "phone": user.get("phone"),
        "joined_at": user.get("joined_at"),
        "location": user.get("location"),
        "created_at": datetime.utcnow(),
        "last_login": None,
    }
    users_col.insert_one(doc)
    print(f"✅ Created: {user['email']} / {user['password']} (role: {user['role']})")

print("\nDone.")
