﻿import json
import os
import urllib.request
from pymongo import MongoClient
from dotenv import load_dotenv

load_dotenv(r"C:\Users\hp\Downloads\PFE_PROJET_chorouk\Backend\.env")
client = MongoClient(os.getenv("MONGO_URI"))
db = client[os.getenv("MONGO_DB_NAME", "nova_db")]
print("employees", db["employees"].count_documents({}))
print("certificates", db["certificates"].count_documents({}))
print("trainings", db["trainings"].count_documents({}))

payload = json.dumps({"email":"hr1@nttdata.com","password":"hr11234"}).encode()
req = urllib.request.Request("http://127.0.0.1:8000/auth/login", data=payload, headers={"Content-Type":"application/json"}, method="POST")
with urllib.request.urlopen(req, timeout=20) as resp:
    login = json.loads(resp.read().decode())
    print("login_status", resp.status, login.get("role"))
    token = login["access_token"]
    headers = {"Authorization": "Bearer " + token}
    for path in ["dashboard/employees-stats", "dashboard/certificates-stats"]:
        req2 = urllib.request.Request("http://127.0.0.1:8000/" + path, headers=headers, method="GET")
        with urllib.request.urlopen(req2, timeout=20) as resp2:
            data = json.loads(resp2.read().decode())
            print(path, resp2.status, data)
