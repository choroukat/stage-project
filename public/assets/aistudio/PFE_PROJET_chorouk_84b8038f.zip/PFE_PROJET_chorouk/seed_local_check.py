import os
from datetime import datetime, timedelta
from pathlib import Path

from dotenv import load_dotenv
from pymongo import MongoClient

# ------------------------------------------------------------------
# 1) Load the project environment exactly like the app does
# ------------------------------------------------------------------
ROOT = Path(__file__).resolve().parent
backend_env = ROOT / "Backend" / ".env"
workspace_env = ROOT / ".env"

if backend_env.exists():
    load_dotenv(backend_env, override=True)
elif workspace_env.exists():
    load_dotenv(workspace_env, override=True)
else:
    raise FileNotFoundError("No .env file found in Backend/ or project root")

MONGO_URI = os.getenv("MONGO_URI")
MONGO_DB_NAME = os.getenv("MONGO_DB_NAME", "nova_db")

if not MONGO_URI:
    raise RuntimeError("MONGO_URI is missing. Add it to Backend/.env")

print(f"Using MongoDB URI: {MONGO_URI[:80]}...")
print(f"Database: {MONGO_DB_NAME}")

# ------------------------------------------------------------------
# 2) Connect and show DB state
# ------------------------------------------------------------------
client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=15000)
db = client[MONGO_DB_NAME]

print("PING:")
print(client.admin.command("ping"))

print("Collections before:")
print(db.list_collection_names())

# ------------------------------------------------------------------
# 3) Seed users (HR + Manager)
# ------------------------------------------------------------------
users_col = db["users"]
users_col.delete_many({})

from passlib.context import CryptContext
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

users_to_create = []
for u in [
    {"full_name":"Aya Bensalem","email":"hr1@nttdata.com","password":"hr11234","role":"hr"},
    {"full_name":"Fatima Zohra El Amrani","email":"hr2@nttdata.com","password":"hr21234","role":"hr"},
    {"full_name":"Nadia Khalil","email":"hr3@nttdata.com","password":"hr31234","role":"hr"},
    {"full_name":"Hicham Benali","email":"hr4@nttdata.com","password":"hr41234","role":"hr"},
    {"full_name":"Sara Idrissi","email":"hr5@nttdata.com","password":"hr51234","role":"hr"},
    {"full_name":"Karim Bensouda","email":"manager1@nttdata.com","password":"manager11234","role":"management"},
    {"full_name":"Mehdi Tahiri","email":"manager2@nttdata.com","password":"manager21234","role":"management"},
    {"full_name":"Leila Fassi","email":"manager3@nttdata.com","password":"manager31234","role":"management"},
    {"full_name":"Youssef Chraibi","email":"manager4@nttdata.com","password":"manager41234","role":"management"},
    {"full_name":"Amina Berrada","email":"manager5@nttdata.com","password":"manager51234","role":"management"},
]:
    users_to_create.append({
        "full_name": u["full_name"],
        "email": u["email"],
        "hashed_password": hash_password(u["password"]),
        "role": u["role"],
        "department": "Ressources Humaines" if u["role"] == "hr" else "IT & Digital",
        "phone": "+212 6 00 00 00 00",
        "joined_at": datetime.utcnow().strftime("%Y-%m-%d"),
        "location": "Morocco",
        "created_at": datetime.utcnow().isoformat(),
        "last_login": None,
    })

users_col.insert_many(users_to_create)
print(f"Inserted users: {users_col.count_documents({})}")

# ------------------------------------------------------------------
# 4) Seed employees / trainings / certificates for dashboard
# ------------------------------------------------------------------
employees_col = db["employees"]
certificates_col = db["certificates"]
trainings_col = db["trainings"]

employees_col.delete_many({})
certificates_col.delete_many({})
trainings_col.delete_many({})

employees = [
    {
        "employee_id": "EMP-1001",
        "employee_name": "Aya Bensalem",
        "email": "aya.bensalem@nttdata.com",
        "department": "Ressources Humaines",
        "job_title": "HR Business Partner",
        "location": "Tanger",
        "skills": ["Communication", "Recruitment", "HR Analytics", "Leadership"],
        "skill_1": "Communication",
        "skill_2": "Recruitment",
        "skill_3": "HR Analytics",
        "skill_4": "Leadership",
        "skill_5": "Culture",
        "skill_count": 5,
        "joined_at": "2021-05-12",
        "created_at": datetime.utcnow().isoformat(),
    },
    {
        "employee_id": "EMP-1002",
        "employee_name": "Karim Bensouda",
        "email": "karim.bensouda@nttdata.com",
        "department": "IT & Digital",
        "job_title": "Senior Product Manager",
        "location": "Casablanca",
        "skills": ["Python", "SQL", "Agile", "Cloud", "Docker"],
        "skill_1": "Python",
        "skill_2": "SQL",
        "skill_3": "Agile",
        "skill_4": "Cloud",
        "skill_5": "Docker",
        "skill_count": 5,
        "joined_at": "2020-02-18",
        "created_at": datetime.utcnow().isoformat(),
    },
    {
        "employee_id": "EMP-1003",
        "employee_name": "Salma El Idrissi",
        "email": "salma.elidrissi@nttdata.com",
        "department": "Data & AI",
        "job_title": "Data Analyst",
        "location": "Rabat",
        "skills": ["Python", "Power BI", "SQL", "Statistics", "Machine Learning"],
        "skill_1": "Python",
        "skill_2": "Power BI",
        "skill_3": "SQL",
        "skill_4": "Statistics",
        "skill_5": "Machine Learning",
        "skill_count": 5,
        "joined_at": "2022-09-04",
        "created_at": datetime.utcnow().isoformat(),
    },
]
employees_col.insert_many(employees)

trainings = [
    {"training_id": "TRN-001", "training_title": "Python for Data Science", "provider": "Coursera", "skill_acquired": "Python"},
    {"training_id": "TRN-002", "training_title": "SQL Fundamentals", "provider": "Udemy", "skill_acquired": "SQL"},
    {"training_id": "TRN-003", "training_title": "Power BI Advanced", "provider": "Microsoft Learn", "skill_acquired": "Power BI"},
]
trainings_col.insert_many(trainings)

base_time = datetime.utcnow()
certificates = []
for idx, emp in enumerate(employees, start=1):
    training = trainings[(idx - 1) % len(trainings)]
    issue_date = base_time - timedelta(days=30 * ((idx % 9) + 1))
    expiry_date = issue_date + timedelta(days=365)
    status = "issued" if idx % 3 != 0 else "failed"
    if idx % 5 == 0:
        status = "expired"
    score = 78 + (idx * 3) % 18
    certificates.append({
        "certificate_id": f"CERT-{1000 + idx}",
        "employee_id": emp["employee_id"],
        "employee_name": emp["employee_name"],
        "department": emp["department"],
        "training_title": training["training_title"],
        "provider": training["provider"],
        "skill_acquired": training["skill_acquired"],
        "status": status,
        "issue_date": issue_date,
        "expiry_date": expiry_date,
        "score": score,
        "homework_score": min(100, score - 5),
        "quiz_score": min(100, score + 2),
        "assignment_score": min(100, score + 4),
        "exam_score": min(100, score + 7),
        "scores": {
            "total": score,
            "homework": min(100, score - 5),
            "quiz": min(100, score + 2),
            "assignment": min(100, score + 4),
            "exam": min(100, score + 7),
        },
        "created_at": datetime.utcnow().isoformat(),
    })
certificates_col.insert_many(certificates)

print("Counts after seed: ")
print("users", users_col.count_documents({}))
print("employees", employees_col.count_documents({}))
print("trainings", trainings_col.count_documents({}))
print("certificates", certificates_col.count_documents({}))

# ------------------------------------------------------------------
# 5) Quick verification of the expected record shape
# ------------------------------------------------------------------
print("Sample user:", users_col.find_one({"email": "hr1@nttdata.com"}, {"_id": 0, "email": 1, "role": 1, "full_name": 1}))
print("Sample employee:", employees_col.find_one({}, {"_id": 0, "employee_id": 1, "department": 1}))
print("Sample cert:", certificates_col.find_one({}, {"_id": 0, "certificate_id": 1, "status": 1, "department": 1}))

print("SEED COMPLETE")
