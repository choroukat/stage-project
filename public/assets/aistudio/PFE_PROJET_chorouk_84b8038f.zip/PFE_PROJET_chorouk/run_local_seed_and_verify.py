import json
import os
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path

from dotenv import load_dotenv
from pymongo import MongoClient
from passlib.context import CryptContext

ROOT = Path(__file__).resolve().parent
backend_env = ROOT / "Backend" / ".env"
workspace_env = ROOT / ".env"
if backend_env.exists():
    load_dotenv(backend_env, override=True)
elif workspace_env.exists():
    load_dotenv(workspace_env, override=True)
else:
    raise FileNotFoundError("Missing .env")

MONGO_URI = os.getenv("MONGO_URI")
MONGO_DB_NAME = os.getenv("MONGO_DB_NAME", "nova_db")
BASE_URL = "http://127.0.0.1:8000"

if not MONGO_URI:
    raise RuntimeError("MONGO_URI is missing")

print("DB:", MONGO_DB_NAME)
client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=15000)
db = client[MONGO_DB_NAME]

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

users = [
    {"full_name":"Aya Bensalem","email":"hr1@nttdata.com","password":"hr11234","role":"hr"},
    {"full_name":"Karim Bensouda","email":"manager1@nttdata.com","password":"manager11234","role":"management"},
]

users_col = db["users"]
users_col.delete_many({})
users_col.insert_many([
    {
        "full_name": u["full_name"],
        "email": u["email"],
        "hashed_password": hash_password(u["password"]),
        "role": u["role"],
        "department": "Ressources Humaines" if u["role"] == "hr" else "IT & Digital",
        "phone": "+212 6 00 00 00 00",
        "joined_at": datetime.utcnow().strftime("%Y-%m-%d"),
        "location": "Morocco",
        "created_at": datetime.utcnow().isoformat(),
        "last_login": None,
    }
    for u in users
])

employees_col = db["employees"]
certificates_col = db["certificates"]
trainings_col = db["trainings"]

employees_col.delete_many({})
certificates_col.delete_many({})
trainings_col.delete_many({})

employees = [
    {
        "employee_id": "EMP-1001",
        "employee_name": "Aya Bensalem",
        "email": "aya.bensalem@nttdata.com",
        "department": "Ressources Humaines",
        "job_title": "HR Business Partner",
        "location": "Tanger",
        "skills": ["Communication", "Recruitment", "HR Analytics", "Leadership"],
        "skill_1": "Communication",
        "skill_2": "Recruitment",
        "skill_3": "HR Analytics",
        "skill_4": "Leadership",
        "skill_5": "Culture",
        "skill_count": 5,
        "joined_at": "2021-05-12",
        "created_at": datetime.utcnow().isoformat(),
    },
    {
        "employee_id": "EMP-1002",
        "employee_name": "Karim Bensouda",
        "email": "karim.bensouda@nttdata.com",
        "department": "IT & Digital",
        "job_title": "Senior Product Manager",
        "location": "Casablanca",
        "skills": ["Python", "SQL", "Agile", "Cloud", "Docker"],
        "skill_1": "Python",
        "skill_2": "SQL",
        "skill_3": "Agile",
        "skill_4": "Cloud",
        "skill_5": "Docker",
        "skill_count": 5,
        "joined_at": "2020-02-18",
        "created_at": datetime.utcnow().isoformat(),
    },
]
employees_col.insert_many(employees)

trainings = [
    {"training_id": "TRN-001", "training_title": "Python for Data Science", "provider": "Coursera", "skill_acquired": "Python"},
    {"training_id": "TRN-002", "training_title": "SQL Fundamentals", "provider": "Udemy", "skill_acquired": "SQL"},
]
trainings_col.insert_many(trainings)

base_time = datetime.utcnow()
certificates = []
for idx, emp in enumerate(employees, start=1):
    training = trainings[(idx - 1) % len(trainings)]
    issue_date = base_time - timedelta(days=30 * idx)
    expiry_date = issue_date + timedelta(days=365)
    score = 82 + idx * 5
    certificates.append({
        "certificate_id": f"CERT-{1000 + idx}",
        "employee_id": emp["employee_id"],
        "employee_name": emp["employee_name"],
        "department": emp["department"],
        "training_title": training["training_title"],
        "provider": training["provider"],
        "skill_acquired": training["skill_acquired"],
        "status": "passed" if idx % 2 == 0 else "issued",
        "issue_date": issue_date,
        "expiry_date": expiry_date,
        "score": score,
        "homework_score": score - 5,
        "quiz_score": score + 2,
        "assignment_score": score + 4,
        "exam_score": score + 7,
        "scores": {
            "total": score,
            "homework": score - 5,
            "quiz": score + 2,
            "assignment": score + 4,
            "exam": score + 7,
        },
        "created_at": datetime.utcnow().isoformat(),
    })
certificates_col.insert_many(certificates)

print("DB counts:", users_col.count_documents({}), employees_col.count_documents({}), trainings_col.count_documents({}), certificates_col.count_documents({}))

# login check
payload = json.dumps({"email":"hr1@nttdata.com","password":"hr11234"}).encode()
req = urllib.request.Request(BASE_URL + "/auth/login", data=payload, headers={"Content-Type":"application/json"}, method="POST")
with urllib.request.urlopen(req, timeout=20) as resp:
    login = json.loads(resp.read().decode())
    print("login_status", resp.status, login.get("role"))
    token = login["access_token"]
    headers = {"Authorization": "Bearer " + token}

    for path in ["/dashboard/employees-stats", "/dashboard/certificates-stats"]:
        req2 = urllib.request.Request(BASE_URL + path, headers=headers, method="GET")
        with urllib.request.urlopen(req2, timeout=20) as resp2:
            data = json.loads(resp2.read().decode())
            print(path, resp2.status)
            print(json.dumps(data, ensure_ascii=False)[:800])

print("END")
