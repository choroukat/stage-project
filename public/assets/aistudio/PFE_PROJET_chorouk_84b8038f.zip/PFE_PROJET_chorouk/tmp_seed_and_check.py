﻿import os
import subprocess
import sys
from pathlib import Path
from pymongo import MongoClient
from dotenv import load_dotenv

root = Path(r"C:\Users\hp\Downloads\PFE_PROJET_chorouk")
backend = root / "Backend"
venv_python = root / ".venv\Scripts\python.exe"
load_dotenv(backend / ".env")

subprocess.run([str(venv_python), str(backend / "scripts" / "seed_demo_data.py")], check=True)

client = MongoClient(os.getenv("MONGO_URI"))
db = client[os.getenv("MONGO_DB_NAME", "nova_db")]
print("users", db["users"].count_documents({}))
print("employees", db["employees"].count_documents({}))
print("certificates", db["certificates"].count_documents({}))
print("trainings", db["trainings"].count_documents({}))
print("sample_employee", db["employees"].find_one({}, {"_id": 0, "employee_id": 1, "department": 1}))
print("sample_certificate", db["certificates"].find_one({}, {"_id": 0, "certificate_id": 1, "status": 1}))
